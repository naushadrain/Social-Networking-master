package com.project.socialnetwork.utils;

public class ResponseUtils {

    public static final String USER_SUCCESS = "User Added Successfully";
    public static final String USER_PROFILE_CREATE = "User Profile Created Successfully";
    public static final String USER_PROFILE_UPDATE = "User Profile Updated Successfully";
    public static final String POST_CREATE = "Post Created Successfully";
    public static final String DELETE = "Deleted Successfully";




}
